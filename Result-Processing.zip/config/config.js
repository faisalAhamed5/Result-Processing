module.exports = {
  "development": {
    "username": "itrrsbnqkoflxg",
    "password": 'd29a5da44d8dca96ca7860a605bce06ac09464142de311d79c91aba7df91f064',
    "database": "dat4u3471vmmnl",
    "host": "ec2-52-6-178-202.compute-1.amazonaws.com",
    "dialect": "postgres",
    "port": 5432,
     
  },
  "test": {
    "username": "itrrsbnqkoflxg",
    "password": 'd29a5da44d8dca96ca7860a605bce06ac09464142de311d79c91aba7df91f064',
    "database": "dat4u3471vmmnl",
    "host": "ec2-52-6-178-202.compute-1.amazonaws.com",
    "dialect": "postgres",
    "port": 5432,
     
  },
  "production": {
    "username": "itrrsbnqkoflxg",
    "password": 'd29a5da44d8dca96ca7860a605bce06ac09464142de311d79c91aba7df91f064',
    "database": "dat4u3471vmmnl",
    "host": "ec2-52-6-178-202.compute-1.amazonaws.com",
    "dialect": "postgres",
    "port": 5432,
     
  }
};
